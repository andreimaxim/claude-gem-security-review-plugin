"""Apply documented adjudications and build a self-contained evidence dashboard."""

from collections import Counter, defaultdict
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from statistics import mean, median
import tarfile


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval')
NEW = ROOT / 'quality-check-opus-fable'
OLD = ROOT / 'quality-check-20261010'
ADDITIONAL = ROOT / 'quality-check-additional'
OUTPUT = ROOT / 'comparison'
MATCHED = ['actioncable', 'actionmailbox', 'actionmailer', 'actionpack', 'actiontext']
MODELS = [
    {'id': 'opus-original', 'name': 'Opus 5.5', 'setting': 'Original prompt',
     'note': 'Worker effort not captured; parent was high. Original prompt.', 'color': '#567690'},
    {'id': 'opus-low', 'name': 'Opus 5.5', 'setting': 'Low · revised prompt',
     'note': 'Explicit low effort; adds preference for version-tagged raw source URLs.', 'color': '#ad6b4c'},
    {'id': 'fable-low', 'name': 'Fable 5.1', 'setting': 'Low · partial batch',
     'note': '51 completed reports: five complete gems plus one Action View report. Revised prompt.', 'color': '#826ca5'},
    {'id': 'sonnet-high', 'name': 'Sonnet 5.5', 'setting': 'High · revised prompt',
     'note': 'Explicit high effort; revised prompt. Reviewed in the first wave.', 'color': '#237981'},
    {'id': 'sonnet-medium', 'name': 'Sonnet 5.5', 'setting': 'Medium · revised prompt',
     'note': '100 completed reports. Same frozen prompt and fixtures as Sonnet/high; medium worker effort verified in every trace. Reviewed in a third wave using the settled rubric.', 'color': '#4e67a2'},
    {'id': 'haiku-high', 'name': 'Haiku 5.5', 'setting': 'High · revised prompt',
     'note': 'Explicit high effort; revised prompt. Reviewed in the first wave.', 'color': '#8b762a'},
]
PARSER_KEYS = {'query_baseline_not_new', 'invented_parser_impact', 'parser_not_new_for_this_app'}
RSPEC_MINOR = {'R061', 'R075', 'R123', 'R137', 'R182', 'R202', 'R233', 'R191', 'R220', 'R248'}


def verdict(issues):
    categories = {f['category'] for f in issues if f['severity'] == 'material'}
    return ('needs_correction' if 'false_claim' in categories else
            'insufficient' if 'material_omission' in categories else
            'needs_verification' if 'unsupported_claim' in categories else
            'no_material_issue_found')


def summarize(rows):
    groups = {}
    for model in MODELS:
        selected = [r for r in rows if r['variant'] == model['id']]
        if not selected:
            continue
        by_gem = defaultdict(list)
        for row in selected:
            by_gem[row['gem']].append(row)
        pairs = different = mixed = repeated = 0
        for group in by_gem.values():
            counts = Counter(r['verdict'] for r in group)
            total = len(group) * (len(group) - 1) // 2
            pairs += total
            different += total - sum(n * (n - 1) // 2 for n in counts.values())
            repeated += len(group) > 1
            mixed += len(counts) > 1
        groups[model['id']] = {
            'reports': len(selected), 'verdicts': Counter(r['verdict'] for r in selected),
            'rawVerdicts': Counter(r['rawVerdict'] for r in selected),
            'noRecordedFindings': sum(not r['issues'] for r in selected),
            'costUsd': sum(r['costUsd'] for r in selected),
            'meanCostUsd': mean(r['costUsd'] for r in selected),
            'medianWorkerSeconds': median(r['seconds'] for r in selected),
            'medianWorkerTools': median(r['tools'] for r in selected),
            'medianWords': median(r['words'] for r in selected),
            'differentVerdictPairs': different, 'withinGemPairs': pairs,
            'pairDisagreement': different / pairs if pairs else None,
            'mixedGems': mixed, 'repeatedGems': repeated,
            'perGem': {g: Counter(r['verdict'] for r in rs) for g, rs in by_gem.items()},
        }
    return groups


def main():
    OUTPUT.mkdir(exist_ok=True)
    snapshot = ROOT / 'application.tar'
    assert sha256(snapshot.read_bytes()).hexdigest() == '9b53089b699d39102c41a5fec5ee192379e65583a83f9417ef0f29dbab413d01'
    checked = 0
    with tarfile.open(snapshot) as archive:
        for member in archive.getmembers():
            if member.isfile():
                path = Path(member.name)
                assert path.read_bytes() == archive.extractfile(member).read(), path
                checked += 1
    rows, adjudications, auxiliary = [], [], []
    for directory in [NEW, OLD, ADDITIONAL]:
        results = json.loads((directory / 'results.json').read_text())
        manifest = {r['id']: r for r in json.loads((directory / 'private-manifest.json').read_text())}
        findings = {(f['review'], f['key']): f for f in results['findings']}
        for report in results['reports']:
            source = manifest[report['id']]
            issues = []
            for key in report['finding_keys']:
                issue = deepcopy(findings[report['review'], key])
                evidence = [e for e in issue.pop('report_evidence') if e['id'] == report['id']]
                issue['quote'] = evidence[0]['quote']
                issue['additionalQuotes'] = [e['quote'] for e in evidence[1:] if e['quote']]
                if directory == NEW and report['id'] == 'R222' and key == 'rack3_parser_baseline':
                    issue['originalQuote'] = issue['quote']
                    issue['quote'] = ('- Semicolons are no longer accepted as query-string separators (`a=1;b=2`).\n'
                                      '- Parameter names with leading brackets (`[foo]=bar`) are now kept as the literal key.')
                if directory == NEW and (key in PARSER_KEYS or
                        (key == 'rspec8_fixture_prerequisite' and report['id'] in RSPEC_MINOR)):
                    issue['originalSeverity'] = issue['severity']
                    issue['originalCategory'] = issue['category']
                    issue['severity'] = 'minor'
                    issue['category'] = 'minor_inaccuracy'
                    issue['adjudication'] = ('Conditional smoke-test advice does not prescribe a migration; '
                        'the parser delta is still inaccurate. See CALIBRATION.md.' if key in PARSER_KEYS else
                        'Optional adjacent RSpec upgrade is outside the scoped migration; '
                        'retain fixture prerequisite as a follow-up. See PACK-ADJUDICATION.md.')
                    adjudications.append({'id': report['id'], 'key': key, 'reason': issue['adjudication']})
                issues.append(issue)
            adjusted = verdict(issues)
            if source['kind'] != 'candidate':
                if directory == NEW:
                    auxiliary.append({'id': report['id'], 'kind': source['kind'],
                                      'rawVerdict': report['verdict'], 'verdict': adjusted,
                                      'priorVerdict': source.get('priorVerdict'),
                                      'expected': source.get('expected'), 'issues': issues})
                continue
            text = Path(source['anonymousReport']).read_text()
            original = Path(source['report'])
            assert sha256(original.read_bytes()).hexdigest() == source['reportSha256']
            for issue in issues:
                assert not issue['quote'] or issue['quote'] in text
                assert all(quote in text for quote in issue['additionalQuotes'])
            rows.append({
                'id': f'{directory.name}/{report["id"]}', 'reviewId': report['id'],
                'variant': source['variant'], 'gem': report['gem'],
                'verdict': adjusted, 'rawVerdict': report['verdict'],
                'coverage': report['coverage'], 'issues': issues,
                'report': text, 'reportSha256': source['reportSha256'],
                'costUsd': source['costUsd'], 'seconds': source['usage']['duration_ms'] / 1000,
                'tools': source['toolCalls'], 'words': len(text.split()),
                'originalReport': str(original.resolve().relative_to(ROOT.resolve())),
                'parentError': bool(source.get('parentError')),
            })
    assert len(rows) == 551
    assert len({r['originalReport'] for r in rows}) == 551
    matched = [r for r in rows if r['gem'] in MATCHED]
    assert Counter(r['variant'] for r in matched) == {m['id']: 50 for m in MODELS}
    anchors = [r for r in auxiliary if r['kind'] == 'anchor']
    controls = [r for r in auxiliary if r['kind'] == 'control']
    summary = {
        'all': summarize(rows), 'matched': summarize(matched),
        'validation': {'applicationSnapshotFiles': checked, 'originalReportHashes': len(rows),
                       'adjudicatedFindingMappings': len(adjudications),
                       'changedCandidateVerdicts': sum(r['verdict'] != r['rawVerdict'] for r in rows),
                       'anchorAgreementBefore': sum(r['rawVerdict'] == r['priorVerdict'] for r in anchors),
                       'anchorAgreementAfter': sum(r['verdict'] == r['priorVerdict'] for r in anchors),
                       'anchors': len(anchors),
                       'incorrectControlsRejected': sum(r['expected'] == 'incorrect' and r['verdict'] == 'needs_correction' for r in controls),
                       'correctControlsFullyAccepted': sum(r['expected'] == 'correct' and r['verdict'] == 'no_material_issue_found' for r in controls)},
        'additionalReview': json.loads((ADDITIONAL / 'summary.json').read_text()),
    }
    payload = {'models': MODELS, 'matchedGems': MATCHED, 'reports': rows, 'summary': summary}
    encoded = json.dumps(payload, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    (OUTPUT / 'data.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    template = Path('.amp/in/gem-upgrade-eval/comparison-template.html').read_text()
    assert template.count('__COMPARISON_DATA__') == 1
    (OUTPUT / 'index.html').write_text(template.replace('__COMPARISON_DATA__', encoded))
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
