import { chromium } from '/home/andrei/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const root = resolve('.amp/in/artifacts/gem-upgrade-eval/comparison');
const data = JSON.parse(await readFile(root + '/data.json', 'utf8'));
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 1100 }, acceptDownloads: true });
const page = await context.newPage();
const errors = [], requests = [];
page.on('pageerror', error => errors.push(error.message));
page.on('request', request => requests.push(request.url()));
await page.goto(pathToFileURL(root + '/index.html').href);
await page.waitForSelector('.run');
assert.equal(await page.locator('.run').count(), 300);
assert.equal(await page.locator('#comparison-body tr').count(), 6);
assert.equal(await page.locator('#matrix-body tr').count(), 5);
assert.match(await page.locator('#scope-note').innerText(), /^300 reports shown/);
assert.equal(await page.locator('#study-total').innerText(), '551');
assert.match(await page.locator('#study-scope').innerText(), /10 Rails gems · 6 configurations/);
assert.match(await page.locator('#variation').innerText(), /Sonnet · medium/);
assert.match(await page.locator('#scatter').innerText(), /Sonnet · medium/);
const displayed = await page.locator('.quality-number').allInnerTexts();
assert.deepEqual(displayed.map(s => Number.parseInt(s)), [92, 34, 70, 76, 56, 84]);
await page.screenshot({ path: root + '/matched-desktop.png', fullPage: true });

// Independently count unequal pairs by enumeration, not the UI's count formula.
function disagreement(rows, basis) {
  let total = 0, different = 0;
  for (let i = 0; i < rows.length; i++) for (let j = i + 1; j < rows.length; j++) {
    if (rows[i].gem === rows[j].gem) {
      total++;
      if (rows[i][basis] !== rows[j][basis]) different++;
    }
  }
  return total ? Math.round(different / total * 100) + '%' : '—';
}
async function checkChartLabels() {
  const defects = await page.locator('#scatter svg').evaluate(svg => {
    const labels = [...svg.querySelectorAll('g text')].map(el => ({ box: el.getBBox(), text: el.textContent }));
    const markers = [...svg.querySelectorAll('g circle[r="5"]')].map(el => el.getBBox());
    const overlap = (a, b) => a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
    return labels.flatMap((label, index) => {
      const defects = [];
      if (label.box.x < 53 || label.box.x + label.box.width > svg.viewBox.baseVal.width - 8 || label.box.y < 30 || label.box.y + label.box.height > 239) defects.push('clipped: ' + label.text);
      if (labels.slice(index + 1).some(other => overlap(label.box, other.box))) defects.push('label overlap: ' + label.text);
      if (markers.some(marker => overlap(label.box, marker))) defects.push('marker overlap: ' + label.text);
      return defects;
    });
  });
  assert.deepEqual(defects, []);
}
let combinations = 0;
for (const scope of ['matched', 'all']) {
  await page.locator('#' + scope).click();
  const gems = scope === 'matched' ? data.matchedGems : [...new Set(data.reports.map(r => r.gem))].sort();
  for (const gem of ['all', ...gems]) {
    await page.locator('#gem').selectOption(gem);
    for (const basis of ['verdict', 'rawVerdict']) {
      await page.locator('#basis').selectOption(basis);
      const selected = data.reports.filter(r => gems.includes(r.gem) && (gem === 'all' || r.gem === gem));
      assert.equal(await page.locator('.run').count(), selected.length);
      const variation = await page.locator('#variation .value').allInnerTexts();
      assert.deepEqual(variation, data.models.map(m => disagreement(selected.filter(r => r.variant === m.id), basis)));
      for (const axis of ['time', 'cost']) {
        await page.locator('#axis').selectOption(axis);
        await checkChartLabels();
      }
      for (const m of data.models) {
        const rows = selected.filter(r => r.variant === m.id);
        const el = page.locator(`[data-model="${m.id}"]`);
        if (!rows.length) {
          assert.match(await el.innerText(), /No completed reports/);
          continue;
        }
        const ok = rows.filter(r => r[basis] === 'no_material_issue_found').length;
        assert.match(await el.locator('.quality-number').innerText(), new RegExp(`^${Math.round(ok / rows.length * 100)}%`));
        assert.match(await el.locator('.quality-number').innerText(), new RegExp(`${ok} of ${rows.length} reports`));
      }
      combinations++;
    }
  }
}
await page.locator('#gem').selectOption('all');
await page.locator('#basis').selectOption('verdict');
assert.equal(await page.locator('.run').count(), 551);
assert.equal(await page.locator('.missing-run').count(), 49);
assert.deepEqual((await page.locator('.quality-number').allInnerTexts()).map(s => Number.parseInt(s)), [93, 50, 71, 68, 63, 89]);
assert.deepEqual(await page.locator('[data-model="sonnet-medium"] .metric').allInnerTexts(), ['$0.12', '22.3s']);
assert.deepEqual(await page.locator('[data-model="sonnet-high"] .metric').allInnerTexts(), ['$0.31', '72.4s']);
await page.screenshot({ path: root + '/all-desktop.png', fullPage: true });

// New reports must show every literal quotation, not just the first per finding.
const mediumIndex = data.reports.findIndex(r => r.variant === 'sonnet-medium' && r.issues.some(i => i.additionalQuotes.length));
assert.ok(mediumIndex >= 0);
const medium = data.reports[mediumIndex];
await page.locator(`[data-report="${mediumIndex}"]`).click();
assert.match(await page.locator('#dialog-subtitle').innerText(), /Sonnet 5.5 \/ Medium/);
assert.equal(await page.locator('#report-text').textContent(), medium.report);
assert.deepEqual(await page.locator('.finding blockquote').allTextContents(),
  medium.issues.flatMap(i => [i.quote, ...i.additionalQuotes].filter(Boolean)));
await page.locator('#close-dialog').click();
await page.locator('#gem').selectOption('actionview');
assert.match(await page.locator('[data-model="fable-low"]').innerText(), /n = 1 completed/);
assert.equal((await page.locator('#variation .value').allInnerTexts())[2], '—');
await page.locator('#gem').selectOption('activemodel');
assert.match(await page.locator('[data-model="fable-low"]').innerText(), /No completed reports/);
await page.locator('#matched').click();
assert.equal(await page.locator('#gem').inputValue(), 'all');
await page.locator('#gem').selectOption('actionpack');
await page.locator('#axis').selectOption('time');
assert.match(await page.locator('#scatter svg').getAttribute('aria-label'), /^Median worker time/);
await page.screenshot({ path: root + '/actionpack-time.png', fullPage: true });

const quoteReport = data.reports.findIndex(r => r.id === 'quality-check-opus-fable/R222');
await page.locator(`[data-report="${quoteReport}"]`).click();
assert.equal(await page.locator('#report-text').textContent(), data.reports[quoteReport].report);
const parserFinding = page.locator('.finding').filter({ hasText: 'rack3 parser baseline' });
assert.match(await parserFinding.locator('blockquote').innerText(), /Semicolons/);
assert.doesNotMatch(await parserFinding.locator('blockquote').innerText(), /invalid encoding/);
await page.keyboard.press('Escape');
assert.equal(await page.locator('#report-dialog').evaluate(el => el.open), false);
await page.locator('#basis').selectOption('rawVerdict');
await page.locator(`[data-report="${quoteReport}"]`).click();
assert.match(await parserFinding.locator('blockquote').innerText(), /^\*\*Removed in 8.1/);
await page.locator('#close-dialog').click();
await page.locator('#basis').selectOption('verdict');
const mediumPack = data.reports.findIndex(r => r.variant === 'sonnet-medium' && r.reviewId === 'R038');
await page.locator(`[data-report="${mediumPack}"]`).click();
assert.ok(await page.locator('.finding.material').count());
assert.match(await page.locator('#dialog-subtitle').innerText(), /Sonnet 5.5 \/ Medium/);
await page.screenshot({ path: root + '/report-detail.png' });
await page.locator('#report-dialog').evaluate(el => { el.scrollTop = el.scrollHeight; });
assert.ok(await page.locator('#report-dialog').evaluate(el => el.scrollTop > 0));
assert.ok(await page.locator('#report-text').evaluate(el => el.getBoundingClientRect().bottom <= innerHeight));
await page.locator('#close-dialog').click();
await page.locator('#methodology summary').click();
const csvEvent = page.waitForEvent('download');
await page.locator('#download-csv').click();
const csv = await csvEvent;
await csv.saveAs(root + '/checked-export.csv');
assert.equal((await readFile(root + '/checked-export.csv', 'utf8')).split('\r\n').length, 7);
const jsonEvent = page.waitForEvent('download');
await page.locator('#download-json').click();
const json = await jsonEvent;
await json.saveAs(root + '/checked-export.json');
assert.deepEqual(JSON.parse(await readFile(root + '/checked-export.json', 'utf8')), data);
await page.locator('#methodology summary').click();
await page.locator('#gem').selectOption('all');
await page.locator('#axis').selectOption('cost');
await page.locator('#basis').selectOption('rawVerdict');
await page.screenshot({ path: root + '/initial-verdicts.png', fullPage: true });
await page.locator('#basis').selectOption('verdict');
for (const width of [390, 768, 1440]) {
  await page.setViewportSize({ width, height: 1000 });
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
  assert.equal(overflow, false, `Body overflow at ${width}`);
  await checkChartLabels();
  if (width === 390) {
    assert.equal(await page.locator('.matrix-hint').isVisible(), true);
    await page.locator('.scroll').evaluate(el => { el.scrollLeft = el.scrollWidth; });
    const lastColumn = await page.locator('#matrix-head th:last-child').boundingBox();
    assert.ok(lastColumn.x >= 0 && lastColumn.x + lastColumn.width <= width);
    await page.locator('.scroll').evaluate(el => { el.scrollLeft = 0; });
    await page.screenshot({ path: root + '/matched-mobile.png', fullPage: true });
  }
}
assert.deepEqual(errors, []);
assert.equal(requests.filter(url => /^https?:/.test(url)).length, 0);
const result = { passed: true, combinations, pageErrors: errors, externalRequests: 0,
  checked: ['matched and all coverage', 'every gem and review basis', 'pair disagreement by independent enumeration',
    'Fable one-report and zero-report states', 'cost/time axis', 'literal report and calibrated quote rendering',
    'Sonnet medium labels and all additional quotations', 'Sonnet medium/high full-batch metrics',
    'non-overlapping chart labels on both axes for all 34 filter states', 'mobile matrix horizontal scrolling',
    'modal click/Escape', 'CSV and JSON downloads', '390/768/1440px body overflow', 'offline file access'],
  screenshots: ['matched-desktop.png','all-desktop.png','actionpack-time.png','report-detail.png','initial-verdicts.png','matched-mobile.png'] };
await writeFile(root + '/browser-check.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(result, null, 2));
await browser.close();
