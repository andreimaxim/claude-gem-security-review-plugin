import json
import subprocess
from pathlib import Path


root = Path(__file__).resolve().parents[3]
artifacts = root / '.amp/in/artifacts/gem-upgrade-eval'
prompt = (
    'Use the gem-upgrade research tool exactly once for fws_librato_logging '
    '1.0.1 to 1.0.1. Wait for its completed report, then summarize that report. '
    'Do not research independently, retry a failed request, or modify files.'
)
command = [
    'claude', '-p', '--input-format', 'stream-json',
    '--plugin-dir', str(root / 'plugins/gem-upgrade'),
    '--setting-sources', '', '--model', 'claude-opus-5-5', '--effort', 'high',
    '--permission-mode', 'dontAsk',
    '--tools', 'Read,Glob,Grep,WebSearch,WebFetch,Agent,ToolSearch',
    '--allowedTools', 'Read,Glob,Grep,WebSearch,WebFetch,mcp__gem-upgrade__research',
    '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
    '--disable-slash-commands', '--output-format', 'stream-json', '--verbose',
    '--forward-subagent-text', '--include-hook-events',
]

for trial in range(1, 4):
    path = artifacts / f'streaming-delivery-{trial}'
    with path.with_suffix('.jsonl').open('x') as trace, path.with_suffix('.stderr').open('x') as errors:
        process = subprocess.Popen(command, cwd=root, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=errors, text=True)
        process.stdin.write(json.dumps({
            'type': 'user', 'parent_tool_use_id': None,
            'message': {'role': 'user', 'content': prompt},
        }) + '\n')
        process.stdin.flush()
        completed = False
        results = []
        for line in process.stdout:
            trace.write(line)
            trace.flush()
            event = json.loads(line)
            if event.get('subtype') == 'task_notification':
                completed = event.get('status') == 'completed'
            if event.get('type') == 'result':
                results.append(event)
                if completed and event.get('result_index', 0) > 0:
                    process.stdin.close()
        assert process.wait() == 0, f'Trial {trial}: process failed'
        assert completed and len(results) == 2, f'Trial {trial}: no follow-up answer'
        assert not results[-1]['is_error'], f'Trial {trial}: follow-up failed'
        assert '1.0.1' in results[-1]['result'] and 'fws_librato_logging' in results[-1]['result']
        assert results[-1]['subagent_stats']['spawned'] == results[-1]['subagent_stats']['completed'] == 1
        print(f'Trial {trial}: one worker completed; main answered in result {results[-1]["result_index"]}.', flush=True)
