import type { Register } from 'claude-code'

export const register: Register = (on) => {
  on('turn.step', ($, e, next) => {
    // Eval-only: keep the dispatcher fixed without a global effort override.
    const request = e.agentId ? e : { ...e, effort: 'low' as const }
    $.ui.log(`GEM_UPGRADE_EVAL_STEP ${JSON.stringify({
      turnId: request.turnId,
      index: request.index,
      agentId: request.agentId ?? null,
      model: request.model,
      effort: request.effort ?? null,
    })}`)
    return next(request)
  })
}
