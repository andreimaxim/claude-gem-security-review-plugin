"""Anonymize the completed additional batch with prior anchors and controls."""

from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import random
import re
import shutil


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval')
OUTPUT = ROOT / 'quality-check-additional'
PRIOR = ROOT / 'quality-check-20261010'
REFERENCE = ROOT / 'quality-check-opus-fable'
spec = importlib.util.spec_from_file_location(
    'previous_preparation', Path(__file__).with_name('prepare-opus-fable-quality.py'))
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)


def main():
    assert not OUTPUT.exists()
    progress = json.loads((ROOT / 'model-comparison/sonnet-medium/progress.json').read_text())
    assert progress['status'] == 'completed' and progress['completedReports'] == 100
    records = []
    for case in progress['cases']:
        for run in case['runs']:
            assert run['configurationVerified'] and run['reportForwardingVerified']
            assert run['workerSettings'] == [['claude-sonnet-5-5', 'medium']]
            trace = Path(run['trace'])
            records.append(previous.candidate('sonnet-medium', case['gem'], trace,
                                              trace.with_suffix('.md'), run['costUsd']))
    assert Counter(r['gem'] for r in records) == {r['gem']: 10 for r in records}
    prior = json.loads((PRIOR / 'private-manifest.json').read_text())
    reviewed = {r['reviewId']: r for r in json.loads((ROOT / 'comparison/data.json').read_text())['reports']
                if r['id'].startswith(PRIOR.name + '/')}
    for record in prior:
        if record['kind'] == 'control':
            records.append({'kind': 'control', 'gem': record['gem'], 'expected': record['expected'],
                            'text': Path(record['anonymousReport']).read_text()})
    groups = sorted({(r['variant'], r['gem']) for r in prior if r['kind'] == 'candidate'})
    for variant, gem in groups:
        record = min((r for r in prior if r['kind'] == 'candidate'
                      and r['variant'] == variant and r['gem'] == gem), key=lambda r: r['reportSha256'])
        records.append({'kind': 'anchor', 'gem': gem, 'priorId': record['id'],
                        'priorVariant': variant, 'priorVerdict': reviewed[record['id']]['verdict'],
                        'text': Path(record['anonymousReport']).read_text()})
    assert Counter(r['kind'] for r in records) == {'candidate': 100, 'anchor': 20, 'control': 10}
    random.Random(20261012).shuffle(records)
    OUTPUT.mkdir()
    for index, record in enumerate(records, 1):
        record['id'] = f'R{index:03}'
        destination = OUTPUT / 'reports' / record['gem'] / f"{record['id']}.md"
        destination.parent.mkdir(parents=True, exist_ok=True)
        text = re.sub(r'/tmp/claude-eval-[^/\s]+/home/cwd/', '[application]/', record.pop('text'))
        destination.write_text(text)
        record['anonymousReport'] = str(destination)
        record['anonymousSha256'] = sha256(destination.read_bytes()).hexdigest()
    (OUTPUT / 'private-manifest.json').write_text(json.dumps(records, indent=2) + '\n')
    for name in ['REFERENCE.md', 'REVIEW-METHOD.md', 'upstream-sources.json']:
        shutil.copy2(REFERENCE / name, OUTPUT / name)
    reference = OUTPUT / 'REFERENCE.md'
    reference.write_text(reference.read_text().replace('Sonnet/Haiku candidate reports', 'initial candidate reports'))
    shutil.copytree(REFERENCE / 'upstream', OUTPUT / 'upstream')
    method = OUTPUT / 'REVIEW-METHOD.md'
    with method.open('a') as output:
        output.write('''
## Previously settled materiality boundaries

Use these boundaries consistently; check the source facts rather than inferring
the model or expected score from report style.

- Semicolon and leading-bracket parsing already follow the modern paths under
  the locked Rack 3.2.6 and current application settings. A false before/after
  prediction is minor unless it requires client/code/configuration migration,
  blocks the upgrade, or imposes a consequential verification gate. Conditional
  traffic checks and ordinary request tests alone do not cross that boundary.
- An optional adjacent RSpec upgrade is a follow-up, not a material omission in
  the assigned Rails component research. If a report directly prescribes an
  RSpec 8 upgrade, the active singular fixture_path setter requires adaptation;
  the accessor is removed in rspec-rails 8, not by merely upgrading Rails.
- Assess the principal actual application surface: Action Pack's routed Live
  SSE controller and Action View's implicit Jbuilder rendering. Missing that
  assessment can be a material research omission without establishing that the
  upgrade breaks either feature. Brief, source-supported low-impact reasoning
  is sufficient; do not require a runtime test or exhaustive patch inventory.
''')
    print(json.dumps({'total': len(records), 'kinds': Counter(r['kind'] for r in records),
                      'perGem': Counter(r['gem'] for r in records)}, indent=2))


if __name__ == '__main__':
    main()
