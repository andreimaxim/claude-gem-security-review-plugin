"""Freeze and anonymize completed reports, controls, and prior-review anchors."""

from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import random
import re
import shutil


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval')
PRIOR = ROOT / 'quality-check-20261010'
OUTPUT = ROOT / 'quality-check-opus-fable'


def candidate(variant, gem, trace, report, cost, parent_error=None):
    rows = [json.loads(line) for line in trace.read_text().splitlines()]
    notices = [r for r in rows if r.get('subtype') == 'task_notification'
               and r.get('status') == 'completed']
    assert len(notices) == 1, trace
    assert report.read_text().strip() == notices[0]['summary'].strip(), report
    results = [r for r in rows if r.get('type') == 'result']
    tool_ids = {b['id'] for r in rows if r.get('type') == 'assistant' and r.get('agent_id')
                for b in r.get('message', {}).get('content', []) if b.get('type') == 'tool_use'}
    return {
        'kind': 'candidate', 'variant': variant, 'gem': gem,
        'trace': str(trace), 'report': str(report), 'parentError': parent_error,
        'reportSha256': sha256(report.read_bytes()).hexdigest(),
        'toolCalls': len(tool_ids), 'usage': notices[0].get('usage'),
        'modelUsage': results[-1].get('modelUsage') if results else None,
        'costUsd': cost, 'text': report.read_text(),
    }


def main():
    assert not OUTPUT.exists()
    records = []
    for directory, variant in [('first-100', 'opus-original'),
                               ('revised-low-inspection', 'opus-low')]:
        source = ROOT / directory
        inspection = json.loads((source / 'inspection.json').read_text())
        for run in inspection['completed']:
            item = candidate(variant, run['gem'], source / run['trace'],
                             source / run['report'], run['sessionCostUsd'])
            assert item['toolCalls'] == sum(run['workerToolCalls'].values())
            assert item['usage']['duration_ms'] / 1000 == run['workerDurationSeconds']
            records.append(item)
    first = json.loads((ROOT / 'model-comparison/inspection.json').read_text())
    for run in first['sets']['fable-low']['runs']:
        if 'completed' not in run['workerStatuses']:
            continue
        assert run['workerSettings'] == [['claude-fable-5-1', 'low']]
        trace = Path(run['trace'])
        report = trace.parent.parent / 'reports' / trace.with_suffix('.md').name
        records.append(candidate('fable-low', run['case'], trace, report,
                                 run['costUsd'], run['error']))
    resumed = json.loads((ROOT / 'model-comparison/retry-20261010-1901/progress.json').read_text())
    for case in resumed['cases']:
        if case['variant'] != 'fable-low':
            continue
        for run in case.get('runs', []):
            if run['workerCompleted'] != 1:
                continue
            assert run['configurationVerified']
            assert run['workerSettings'] == [['claude-fable-5-1', 'low']]
            trace = Path(run['trace'])
            records.append(candidate('fable-low', case['gem'], trace, trace.with_suffix('.md'),
                                     run['costUsd'], run['error']))
    assert Counter(r['variant'] for r in records) == {'opus-original': 100, 'opus-low': 100, 'fable-low': 51}
    assert len({str(Path(r['trace']).resolve()) for r in records}) == 251

    prior_manifest = json.loads((PRIOR / 'private-manifest.json').read_text())
    prior_results = {r['id']: r for r in json.loads((PRIOR / 'results.json').read_text())['reports']}
    for record in prior_manifest:
        if record['kind'] == 'control':
            records.append({'kind': 'control', 'gem': record['gem'], 'expected': record['expected'],
                            'text': Path(record['anonymousReport']).read_text()})
    # One anchor per previous model/gem, selected by hash, never by outcome.
    groups = sorted({(r['variant'], r['gem']) for r in prior_manifest if r['kind'] == 'candidate'})
    for variant, gem in groups:
        record = min((r for r in prior_manifest if r['kind'] == 'candidate'
                      and r['variant'] == variant and r['gem'] == gem), key=lambda r: r['reportSha256'])
        records.append({'kind': 'anchor', 'gem': gem, 'priorId': record['id'],
                        'priorVariant': variant, 'priorVerdict': prior_results[record['id']]['verdict'],
                        'text': Path(record['anonymousReport']).read_text()})
    random.Random(20261011).shuffle(records)
    OUTPUT.mkdir()
    for index, record in enumerate(records, 1):
        record['id'] = f'R{index:03}'
        destination = OUTPUT / 'reports' / record['gem'] / f"{record['id']}.md"
        destination.parent.mkdir(parents=True, exist_ok=True)
        text = re.sub(r'/tmp/claude-eval-[^/\s]+/home/cwd/', '[application]/', record.pop('text'))
        destination.write_text(text)
        record['anonymousReport'] = str(destination)
    (OUTPUT / 'private-manifest.json').write_text(json.dumps(records, indent=2) + '\n')
    for name in ['REFERENCE.md', 'REVIEW-METHOD.md', 'upstream-sources.json']:
        shutil.copy2(PRIOR / name, OUTPUT / name)
    shutil.copytree(PRIOR / 'upstream', OUTPUT / 'upstream')
    with (OUTPUT / 'REFERENCE.md').open('a') as output:
        output.write('\n## Additional verified reference\n\nAction Cable can auto-mount /cable even without an explicit routes entry.\n'
                     'Its target engine initializer mounts the configured path unless disabled:\n'
                     'https://raw.githubusercontent.com/rails/rails/v8.1.4/actioncable/lib/action_cable/engine.rb\n'
                     'The apparent disabling settings in this application are commented examples.\n')
    print(json.dumps({'total': len(records), 'kinds': Counter(r['kind'] for r in records),
                      'perGem': Counter(r['gem'] for r in records)}, indent=2))


if __name__ == '__main__':
    main()
