"""Prepare anonymous completed reports and immutable upstream evidence for review."""

from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
from pathlib import Path
import random
import re
from urllib.request import urlopen


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval')
OUTPUT = ROOT / 'quality-check-20261010'
SOURCES = [
    ('retry-20261010-1939', 'sonnet-high'),
    ('retry-20261010-1954-sonnet', 'sonnet-high'),
    ('retry-20261010-1954-haiku-high', 'haiku-high'),
]


def main():
    OUTPUT.mkdir(exist_ok=False)
    records = []
    seen = set()
    for directory, variant in SOURCES:
        progress = ROOT / 'model-comparison' / directory / 'progress.json'
        state = json.loads(progress.read_text())
        for case in state['cases']:
            if case['variant'] != variant:
                continue
            for run in case.get('runs', []):
                if run['workerCompleted'] != 1:
                    continue
                assert run['configurationVerified'] and not run['error']
                trace = Path(run['trace'])
                assert trace not in seen
                seen.add(trace)
                rows = [json.loads(line) for line in trace.read_text().splitlines()]
                notices = [r for r in rows if r.get('subtype') == 'task_notification'
                           and r.get('status') == 'completed']
                assert len(notices) == 1
                report = trace.with_suffix('.md')
                assert report.read_text().strip() == notices[0]['summary'].strip()
                tool_ids = {block['id'] for row in rows
                            if row.get('type') == 'assistant' and row.get('agent_id')
                            for block in row.get('message', {}).get('content', [])
                            if block.get('type') == 'tool_use'}
                results = [r for r in rows if r.get('type') == 'result']
                records.append({
                    'kind': 'candidate', 'variant': variant, 'gem': case['gem'],
                    'report': str(report), 'trace': str(trace), 'progress': str(progress),
                    'reportSha256': sha256(report.read_bytes()).hexdigest(),
                    'toolCalls': len(tool_ids), 'usage': notices[0].get('usage'),
                    'modelUsage': results[-1].get('modelUsage') if results else None,
                    'costUsd': run['costUsd'], 'text': report.read_text(),
                })
    counts = Counter((r['variant'], r['gem']) for r in records)
    assert len(records) == 200 and len(counts) == 20 and set(counts.values()) == {10}
    controls = [
        ('actionpack', 'correct', 'The installed Rails gems must move together and the Rails constraint needs changing for 8.1.4. This application retains load_defaults 7.0. Ordinary render json: escaping remains enabled unless explicitly overridden; upgrading the gems alone does not adopt the Rails 8.1 JSON defaults. The authentication concern uses head(:unauthorized); its presence warrants checking control flow, not claiming that every such call breaks.'),
        ('actionpack', 'incorrect', 'The installed Rails gems must move together and the Rails constraint needs changing for 8.1.4. Even though this application retains load_defaults 7.0, installing Rails 8.1.4 unconditionally disables JSON response escaping, so the application must add escape: true to every render json: call.'),
        ('activemodel', 'correct', 'The Rails constraint blocks an isolated Active Model 8.1.4 update. The app uses typed Active Model objects, including cached AIAgent instances. The 8.1 integer Marshal compatibility regression was fixed before 8.1.4; the AIAgent attributes inspected here are strings, datetimes and an untyped suggestions value, not integer attributes. Test relevant cache round trips rather than assuming this particular integer issue requires a cache flush.'),
        ('activemodel', 'incorrect', 'The Rails constraint blocks an isolated Active Model 8.1.4 update. Every cached AIAgent has an integer id type. The integer Marshal regression is still unfixed in 8.1.4, so all Redis caches must be flushed before this upgrade.'),
        ('actioncable', 'correct', 'Action Cable is explicitly loaded but the application channel and connection classes are empty scaffolding. Rails components must be upgraded together and the existing Rails constraint excludes 8.1.4. The Redis adapter broadens support to Redis 6; the existing redis ~> 5.2 constraint already excludes Redis 6, so this does not require another pin.'),
        ('actioncable', 'incorrect', 'Action Cable is explicitly loaded but the application channel and connection classes are empty scaffolding. Rails components must be upgraded together and the existing Rails constraint excludes 8.1.4. The existing redis ~> 5.2 constraint permits Redis 6, so upgrading Rails can silently select Redis 6 unless you add a new major-version pin.'),
        ('actionmailbox', 'correct', 'Action Mailbox has no explicit engine loading or feature usage in the inspected application. The Rails metagem still version-couples it to the rest of Rails, and the manifest constraint needs widening for 8.1.4. Ruby >= 3.2 is the same minimum as 8.0.5; the app already specifies Ruby 3.4.7. The new reply_to_address helper does not require installing mailbox tables in an application that does not use mailboxes.'),
        ('actionmailbox', 'incorrect', 'Action Mailbox has no explicit engine loading or feature usage in the inspected application. The Rails metagem still version-couples it to the rest of Rails, and the manifest constraint needs widening for 8.1.4. Rails 8.1 raises the Ruby minimum to 3.4, and every application installing the Action Mailbox gem must create mailbox database tables even when the framework is unused.'),
        ('actiontext', 'correct', 'The Rails constraint must change and all Rails components move together. Action Text has no explicit engine loading or rich-text usage here, so no application rich-text migration is demonstrated. There is nevertheless a dependency change: Action Text 8.1.4 adds action_text-trix ~> 2.1.15, absent from 8.0.5. This belongs in the lockfile impact even for an unused framework.'),
        ('actiontext', 'incorrect', 'The Rails constraint must change and all Rails components move together. Action Text has no explicit engine loading or rich-text usage here. Action Text 8.1.4 has exactly the same runtime dependencies as 8.0.5; it introduces no new gem, so there can be no additional dependency changes beyond Rails version numbers.'),
    ]
    records.extend({'kind': 'control', 'gem': gem, 'expected': expected, 'text': text}
                   for gem, expected, text in controls)
    random.Random(20261010).shuffle(records)
    for index, record in enumerate(records, 1):
        record['id'] = f'R{index:03}'
        folder = OUTPUT / 'reports' / record['gem']
        folder.mkdir(parents=True, exist_ok=True)
        text = re.sub(r'/tmp/claude-eval-[^/\s]+/home/cwd/', '[application]/', record.pop('text'))
        destination = folder / f"{record['id']}.md"
        destination.write_text(text)
        record['anonymousReport'] = str(destination)
    (OUTPUT / 'private-manifest.json').write_text(json.dumps(records, indent=2) + '\n')

    gems = sorted({r['gem'] for r in records})
    paths = [f'{gem}/{filename}' for gem in gems
             for filename in ('CHANGELOG.md', f'{gem}.gemspec')]
    paths += [
        'rails.gemspec', 'railties/lib/rails/application/configuration.rb',
        'actionpack/lib/action_controller/metal/renderers.rb',
        'actionpack/lib/action_controller/metal/head.rb',
        'actionpack/lib/action_dispatch/http/param_builder.rb',
        'actionpack/lib/action_dispatch/http/query_parser.rb',
        'actioncable/lib/action_cable/subscription_adapter/redis.rb',
        'activemodel/lib/active_model/type/integer.rb',
        'activemodel/test/cases/type/integer_test.rb',
        'activesupport/lib/active_support/cache/serializer_with_fallback.rb',
        'activesupport/lib/active_support/json/encoding.rb',
        'activerecord/lib/active_record/schema_dumper.rb',
        'activestorage/lib/active_storage/engine.rb',
        'actiontext/app/models/action_text/rich_text.rb',
    ]

    def fetch(item):
        tag, path = item
        url = f'https://raw.githubusercontent.com/rails/rails/{tag}/{path}'
        with urlopen(url, timeout=60) as response:
            data = response.read()
        destination = OUTPUT / 'upstream' / tag / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        return {'tag': tag, 'path': path, 'url': url, 'sha256': sha256(data).hexdigest()}

    with ThreadPoolExecutor(max_workers=8) as pool:
        sources = list(pool.map(fetch, [(tag, path) for tag in ('v8.0.5', 'v8.1.4') for path in paths]))
    (OUTPUT / 'upstream-sources.json').write_text(json.dumps(sources, indent=2) + '\n')
    print(json.dumps({'candidateCounts': {f'{v}/{g}': n for (v, g), n in counts.items()},
                      'controls': len(controls), 'upstreamFiles': len(sources)}, indent=2))


if __name__ == '__main__':
    main()
