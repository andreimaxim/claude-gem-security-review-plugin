require 'bundler'
require 'digest'
require 'fileutils'
require 'json'
require 'net/http'
require 'open3'
require 'shellwords'
require 'time'
require 'yaml'

root = File.expand_path('../../..', __dir__)
output = File.join(root, '.amp/in/artifacts/gem-upgrade-eval')
corpus_path = File.join(output, 'corpus.json')
snapshot = File.join(output, 'application.tar')
plugin = File.join(output, 'baseline-plugin')
abort "Refusing to overwrite #{corpus_path}" if File.exist?(corpus_path)

lock = Bundler::LockfileParser.new(File.read(File.join(root, 'Gemfile.lock')))
cases = lock.specs.group_by(&:name).sort.map do |name, specs|
  versions = specs.map { |spec| spec.version.to_s }.uniq
  abort "Multiple locked versions for #{name}: #{versions}" unless versions.one?
  current = versions.first
  source = specs.first.source
  if source.is_a?(Bundler::Source::Rubygems)
    url = "https://rubygems.org/api/v1/versions/#{URI.encode_www_form_component(name)}/latest.json"
    response = Net::HTTP.start('rubygems.org', 443, use_ssl: true, open_timeout: 20, read_timeout: 30) do |http|
      http.get(URI(url).request_uri)
    end
    abort "#{name}: HTTP #{response.code}" unless response.is_a?(Net::HTTPSuccess)
    requested = JSON.parse(response.body).fetch('version')
    abort "#{name}: latest #{requested} is a prerelease" if Gem::Version.new(requested).prerelease?
    abort "#{name}: latest #{requested} is older than locked #{current}" if Gem::Version.new(requested) < Gem::Version.new(current)
  elsif source.is_a?(Bundler::Source::Path)
    requested = current
    url = nil
  else
    abort "Unsupported source for #{name}: #{source.class}"
  end
  warn "#{name}: #{current} -> #{requested}"
  {
    'gem' => name, 'currentVersion' => current, 'requestedVersion' => requested,
    'source' => source.class.to_s, 'targetSource' => url,
    'control' => requested == current,
    'platforms' => specs.map { |spec| spec.platform.to_s },
  }
end

files, status = Open3.capture2('git', 'ls-files', '-z', chdir: root)
abort 'git ls-files failed' unless status.success?
paths = files.split("\0").select { |path| File.file?(File.join(root, path)) }
stdout, stderr, status = Open3.capture3('tar', '-cf', snapshot, '--null', '-T', '-', stdin_data: paths.join("\0") + "\0", chdir: root)
abort "Snapshot failed: #{stdout} #{stderr}" unless status.success?
manifest = {
  'createdAt' => Time.now.utc.iso8601,
  'lockfileSha256' => Digest::SHA256.file(File.join(root, 'Gemfile.lock')).hexdigest,
  'applicationSha256' => Digest::SHA256.file(snapshot).hexdigest,
  'targetPolicy' => 'Latest stable RubyGems version; unchanged and vendored gems are same-version controls. One case per distinct locked gem, not per platform.',
  'cases' => cases,
}
File.write(corpus_path, JSON.pretty_generate(manifest) + "\n")
FileUtils.cp_r(File.join(root, 'plugins/gem-upgrade'), plugin)
cases.each do |item|
  name = item.fetch('gem')
  directory = File.join(plugin, 'evals', name)
  FileUtils.mkdir_p(directory)
  File.write(File.join(directory, 'fixture.sh'), "#!/bin/sh\nset -eu\ntar -xf #{snapshot.shellescape}\n")
  request = item.slice('gem', 'currentVersion', 'requestedVersion')
  config = {
    'schema_version' => '1.1', 'name' => name,
    'tags' => [item.fetch('control') ? 'control' : 'upgrade'],
    'context' => { 'scaffold_script' => 'fixture.sh' },
    'execution' => {
      'max_turns' => 100, 'timeout_seconds' => 900,
      'allowed_tools' => ['Read', 'Glob', 'Grep', 'WebSearch', 'WebFetch', 'Agent', 'ToolSearch', 'mcp__gem-upgrade__research'],
      'prompt' => "Use the gem-upgrade research tool exactly once for #{JSON.generate(request)}. Wait for the research report. Do not research independently, retry a failed request, or modify files.",
    },
    'graders' => [
      { 'name' => 'research-dispatched-once', 'type' => 'tool_used', 'tool' => 'mcp__gem-upgrade__research', 'min' => 1, 'max' => 1 },
      { 'name' => 'worker-completed', 'type' => 'regex', 'target' => 'trace', 'pattern' => '"subtype"\\s*:\\s*"task_notification"[^\\n]*"status"\\s*:\\s*"completed"' },
    ],
  }
  File.write(File.join(directory, 'case.yaml'), YAML.dump(config))
end
puts JSON.pretty_generate({ cases: cases.size, upgrades: cases.count { |item| !item['control'] }, controls: cases.count { |item| item['control'] }, plugin: plugin })
