#!/usr/bin/env python3
"""Fill missing model-comparison samples once; preserve every failed attempt."""

import argparse
from collections import Counter
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys


def run_eval(command, folder):
    env = os.environ.copy()
    env.pop('CLAUDE_CODE_EFFORT_LEVEL', None)
    env['CLAUDE_CODE_FORWARD_SUBAGENT_TEXT'] = '1'
    limited = False
    with (folder / 'run.log').open('x') as log:
        process = subprocess.Popen(command, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True, bufsize=1)
        try:
            for line in process.stdout:
                log.write(line)
                log.flush()
                if ' run ' in line or 'error:' in line or 'Interrupted' in line:
                    print(line.rstrip(), flush=True)
                if "You've hit your session limit" in line and not limited:
                    limited = True
                    print('Account limit detected; cancelling this suite and stopping the batch.', flush=True)
                    process.send_signal(signal.SIGINT)
            code = process.wait()
        except KeyboardInterrupt:
            process.send_signal(signal.SIGINT)
            process.wait()
            raise
    (folder / 'exit-code').write_text(f'{code}\n')
    return code, limited


def inspect_case(folder, model, effort):
    aggregate = folder / 'results/aggregate-result.json'
    if not aggregate.exists():
        return []
    data = json.loads(aggregate.read_text())
    records = []
    for case in data['cases']:
        for index, run in enumerate(case['arms']['with'], 1):
            key = f"{case['name']}-{index:02d}"
            trace = folder / f'{key}.jsonl'
            shutil.copyfile(run['tracePath'], trace)
            rows = [json.loads(line) for line in trace.read_text().splitlines()]
            notices = [row for row in rows if row.get('subtype') == 'task_notification']
            completed = [row for row in notices if row.get('status') == 'completed']
            steps = [json.loads(row['text'].split(' ', 1)[1]) for row in rows
                     if row.get('subtype') == 'ui_log'
                     and row.get('text', '').startswith('GEM_UPGRADE_EVAL_STEP ')]
            worker = {(step['model'], step['effort']) for step in steps if step['agentId']}
            main = {(step['model'], step['effort']) for step in steps if not step['agentId']}
            response_models = {row['message']['model'] for row in rows
                               if row.get('type') == 'assistant' and row.get('agent_id')
                               and row['message']['model'] != '<synthetic>'}
            config_ok = (worker == {(model, effort)}
                         and main == {('claude-opus-5-5', 'low')}
                         and response_models == {model})
            for notice in completed:
                (folder / f'{key}.md').write_text(notice['summary'] + '\n')
            records.append({
                'case': case['name'], 'run': index, 'error': run['error'],
                'workerCompleted': len(completed), 'configurationVerified': config_ok,
                'workerSettings': sorted(worker), 'responseModels': sorted(response_models),
                'costUsd': run['costUsd'], 'trace': str(trace),
                'workerUsage': [notice.get('usage') for notice in notices],
            })
    return records


def main():
    root = Path('.amp/in/artifacts/gem-upgrade-eval/model-comparison').resolve()
    previous = json.loads((root / 'inspection.json').read_text())
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output_directory')
    parser.add_argument('variants', nargs='+', choices=list(previous['sets']))
    parser.add_argument('--prior-run', action='append', default=[], type=Path,
                        help='Saved progress.json whose completed reports also count.')
    args = parser.parse_args()
    variants = args.variants
    if len(set(variants)) != len(variants) or any(v not in previous['sets'] for v in variants):
        print('Select unique, known variants: ' + ', '.join(previous['sets']))
        return 2
    completed = Counter()
    for variant in variants:
        for run in previous['sets'][variant]['runs']:
            completed[variant, run['case']] += run['workerStatuses'].count('completed')
    histories = list(dict.fromkeys(path.resolve() for path in args.prior_run))
    for history in histories:
        saved = json.loads(history.read_text())
        for case in saved['cases']:
            if case['variant'] not in variants:
                continue
            if case['status'] != 'finished':
                raise ValueError(f'Cannot resume an active case from {history}')
            for run in case['runs']:
                if run['workerCompleted']:
                    assert run['configurationVerified'], 'Prior worker configuration mismatch'
                    completed[case['variant'], case['gem']] += run['workerCompleted']
    output = root / args.output_directory
    output.mkdir()  # Never overwrite an earlier attempt.
    state = {'status': 'running', 'previousInspection': str(root / 'inspection.json'),
             'previousRuns': [str(path) for path in histories],
             'targetReportsPerConfiguration': 100, 'concurrency': 4,
             'selectedVariants': variants, 'cases': []}
    state_path = output / 'progress.json'
    state_path.write_text(json.dumps(state, indent=2) + '\n')
    for variant in variants:
        prior = previous['sets'][variant]
        plugin = root / variant / 'plugin'
        for case in sorted((plugin / 'evals').glob('*/case.yaml')):
            gem = case.parent.name
            already = completed[variant, gem]
            remaining = 10 - already
            assert 0 <= remaining <= 10
            if not remaining:
                continue
            folder = output / variant / gem
            folder.mkdir(parents=True)
            command = ['claude', 'plugin', 'eval', str(plugin), '--case', gem,
                       '--runs', str(remaining), '--concurrency', '4', '--ablation', 'none',
                       '--model', 'claude-opus-5-5', '--mocks', 'off', '--allow-tools',
                       'WebFetch', 'WebSearch', 'ToolSearch', 'mcp__gem-upgrade__research',
                       '--scaffold', '--trust-plugin', '--no-publish', '--keep-temp',
                       '--output-dir', str(folder / 'results')]
            print(f'=== {variant}: {gem}, {remaining} missing samples ===', flush=True)
            entry = {'variant': variant, 'gem': gem, 'requested': remaining,
                     'previousReports': already, 'command': command, 'status': 'running'}
            state['cases'].append(entry)
            state_path.write_text(json.dumps(state, indent=2) + '\n')
            code, limited = run_eval(command, folder)
            records = inspect_case(folder, prior['workerModel'], prior['workerEffort'])
            entry.update(exitCode=code, quotaLimited=limited, runs=records, status='finished')
            valid = (len(records) == remaining and all(run['workerCompleted'] == 1
                     and run['configurationVerified'] and not run['error'] for run in records))
            if code != 0 or limited or not valid:
                state['status'] = 'stopped-account-limit' if limited else 'stopped-failed-case'
                state_path.write_text(json.dumps(state, indent=2) + '\n')
                print(f"Batch stopped: {state['status']}; evidence: {state_path}", flush=True)
                return 1
            state_path.write_text(json.dumps(state, indent=2) + '\n')
    state['status'] = 'completed'
    state_path.write_text(json.dumps(state, indent=2) + '\n')
    print(f'All missing samples completed: {state_path}', flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
