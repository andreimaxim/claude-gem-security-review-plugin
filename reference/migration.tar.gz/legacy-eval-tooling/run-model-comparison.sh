#!/usr/bin/env bash
set -euo pipefail

root="$PWD/.amp/in/artifacts/gem-upgrade-eval/model-comparison"
for variant in fable-low sonnet-high haiku-high haiku-xhigh; do
  dir="$root/$variant"
  test ! -e "$dir/results"
  printf '\n=== %s %s ===\n' "$variant" "$(date --iso-8601=seconds)"
  # An effort environment override would also override the worker's registration.
  # The eval-only observer pins just the dispatcher to low and logs every step.
  set +e
  env -u CLAUDE_CODE_EFFORT_LEVEL CLAUDE_CODE_FORWARD_SUBAGENT_TEXT=1 \
    claude plugin eval "$dir/plugin" \
      --runs 10 --concurrency 4 --ablation none --model claude-opus-5-5 \
      --mocks off --allow-tools WebFetch WebSearch ToolSearch mcp__gem-upgrade__research \
      --scaffold --trust-plugin --no-publish --keep-temp \
      --output-dir "$dir/results" 2>&1 | tee "$dir/run.log"
  code=${PIPESTATUS[0]}
  set -e
  printf '%s\n' "$code" > "$dir/exit-code"
  printf '=== %s exited %s at %s ===\n' "$variant" "$code" "$(date --iso-8601=seconds)"
  # A scored failure remains evidence; an interrupted or broken suite stops here.
  if (( code > 1 )); then exit "$code"; fi
done
