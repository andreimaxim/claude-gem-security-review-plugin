#!/usr/bin/env python3
"""Run 100 frozen Sonnet/medium trials, including a one-trial configuration check."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
OUTPUT = ROOT / '.amp/in/artifacts/gem-upgrade-eval/model-comparison/sonnet-medium'
PLUGIN = OUTPUT / 'plugin'
MODEL = 'claude-sonnet-5-5'
EFFORT = 'medium'
FIXTURE_HASH = '9b53089b699d39102c41a5fec5ee192379e65583a83f9417ef0f29dbab413d01'

spec = importlib.util.spec_from_file_location(
    'existing_runner', Path(__file__).with_name('resume-model-comparison.py'))
existing_runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(existing_runner)


def now():
    return datetime.now(timezone.utc).isoformat()


def collect_evidence(folder):
    records = existing_runner.inspect_case(folder, MODEL, EFFORT)
    if not records:
        return records
    aggregate = json.loads((folder / 'results/aggregate-result.json').read_text())
    runs = [run for case in aggregate['cases'] for run in case['arms']['with']]
    for record, run in zip(records, runs, strict=True):
        rows = [json.loads(line) for line in Path(record['trace']).read_text().splitlines()]
        notices = [row for row in rows if row.get('subtype') == 'task_notification'
                   and row.get('status') == 'completed']
        workers = [row for row in rows if row.get('type') == 'assistant'
                   and row.get('agent_id')]
        forwarded = False
        if len(notices) == 1:
            answers = [row for row in workers if row['agent_id'] == notices[0]['task_id']]
            if answers:
                final_text = '\n'.join(block['text'] for block in answers[-1]['message']['content']
                                       if block.get('type') == 'text')
                forwarded = bool(final_text) and final_text == notices[0]['summary']
        # Streamed message IDs can repeat; only tool-use IDs identify unique calls.
        tools = {block['id']: block['name'] for row in workers
                 for block in row['message']['content'] if block.get('type') == 'tool_use'}
        results = [row for row in rows if row.get('type') == 'result']
        record.update(
            durationSeconds=run['durationSeconds'],
            startedAt=run['startedAt'],
            reportForwardingVerified=forwarded,
            toolCalls=len(tools),
            tools=dict(Counter(tools.values())),
            modelUsage=results[-1].get('modelUsage') if results else None,
            reportWords=len(notices[0]['summary'].split()) if len(notices) == 1 else None,
        )
    return records


def main():
    fixture = ROOT / '.amp/in/artifacts/gem-upgrade-eval/application.tar'
    assert hashlib.sha256(fixture.read_bytes()).hexdigest() == FIXTURE_HASH
    gems = sorted(path.parent.name for path in (PLUGIN / 'evals').glob('*/case.yaml'))
    assert len(gems) == 10
    plan = [(gems[0], 1, 'smoke'), (gems[0], 9, 'remaining')]
    plan.extend((gem, 10, 'full') for gem in gems[1:])
    assert sum(count for _, count, _ in plan) == 100
    state = {
        'status': 'running', 'startedAt': now(), 'targetReports': 100,
        'workerModel': MODEL, 'workerEffort': EFFORT,
        'dispatcherModel': 'claude-opus-5-5', 'dispatcherEffort': 'low',
        'concurrency': 4, 'fixtureSha256': FIXTURE_HASH,
        'cases': [], 'completedReports': 0,
    }
    state_path = OUTPUT / 'progress.json'
    with state_path.open('x') as output:
        json.dump(state, output, indent=2)
        output.write('\n')

    def save():
        state['updatedAt'] = now()
        temporary = OUTPUT / 'progress.tmp'
        temporary.write_text(json.dumps(state, indent=2) + '\n')
        temporary.replace(state_path)

    try:
        for index, (gem, count, part) in enumerate(plan, 1):
            folder = OUTPUT / f'{index:02d}-{gem}-{part}'
            folder.mkdir()
            command = ['claude', 'plugin', 'eval', str(PLUGIN), '--case', gem,
                       '--runs', str(count), '--concurrency', '4', '--ablation', 'none',
                       '--model', 'claude-opus-5-5', '--mocks', 'off', '--allow-tools',
                       'WebFetch', 'WebSearch', 'ToolSearch', 'mcp__gem-upgrade__research',
                       '--scaffold', '--trust-plugin', '--no-publish', '--keep-temp',
                       '--output-dir', str(folder / 'results')]
            entry = {'gem': gem, 'requested': count, 'part': part, 'status': 'running',
                     'startedAt': now(), 'command': command, 'folder': str(folder)}
            state['cases'].append(entry)
            save()
            print(f'=== {gem}: {count} trials ({part}); {state["completedReports"]}/100 completed ===',
                  flush=True)
            code, limited = existing_runner.run_eval(command, folder)
            records = collect_evidence(folder)
            entry.update(status='finished', finishedAt=now(), exitCode=code,
                         quotaLimited=limited, runs=records)
            state['completedReports'] += sum(record['workerCompleted'] for record in records)
            valid = len(records) == count and all(
                record['workerCompleted'] == 1 and record['configurationVerified']
                and record['reportForwardingVerified'] and not record['error']
                for record in records)
            if code != 0 or limited or not valid:
                state['status'] = 'stopped-account-limit' if limited else 'stopped-failed-case'
                save()
                print(f'Batch stopped: {state["status"]}. Evidence: {state_path}', flush=True)
                return 1
            save()
            print(f'Verified {state["completedReports"]}/100 reports: Sonnet 5.5/medium, exact forwarding.',
                  flush=True)
        state['status'] = 'completed'
        state['finishedAt'] = now()
        save()
        print(f'All 100 trials completed: {state_path}', flush=True)
        return 0
    except BaseException as error:
        state.update(status='stopped-exception', error=repr(error))
        save()
        raise


if __name__ == '__main__':
    sys.exit(main())
