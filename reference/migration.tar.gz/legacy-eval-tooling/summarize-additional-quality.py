"""Validate the additional blind review before joining its private identities."""

from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval/quality-check-additional')


def main():
    manifest = {r['id']: r for r in json.loads((ROOT / 'private-manifest.json').read_text())}
    reports, findings, seen = [], [], set()
    quotations = 0
    for path in sorted(ROOT.glob('review-*.json')):
        data = json.loads(path.read_text())
        indexed = {f['key']: f for f in data['findings']}
        report_index = {r['id']: r for r in data['reports']}
        assert len(indexed) == len(data['findings'])
        assert len(report_index) == len(data['reports'])
        for finding in data['findings']:
            assert finding['category'] in {'false_claim', 'unsupported_claim', 'material_omission', 'minor_inaccuracy'}
            assert finding['severity'] in {'material', 'minor'}
            assert finding['evidence'] and finding['explanation']
            for evidence in finding['report_evidence']:
                rid, quote = evidence['id'], evidence['quote']
                assert finding['key'] in report_index[rid]['finding_keys']
                if quote:
                    assert quote in Path(manifest[rid]['anonymousReport']).read_text(), (rid, quote)
                    quotations += 1
            findings.append({'review': path.name, **finding})
        for report in data['reports']:
            rid = report['id']
            assert rid not in seen
            seen.add(rid)
            source = manifest[rid]
            assert report['gem'] == source['gem']
            assert set(report['coverage']) == {'coupling', 'manifest', 'application', 'delta'}
            assert set(report['coverage'].values()) <= {'correct', 'partial', 'missing', 'wrong', 'not_applicable'}
            issues = [indexed[k] for k in report['finding_keys']]
            for issue in issues:
                assert rid in {e['id'] for e in issue['report_evidence']}
            material = {i['category'] for i in issues if i['severity'] == 'material'}
            verdict = ('needs_correction' if 'false_claim' in material else
                       'insufficient' if 'material_omission' in material else
                       'needs_verification' if 'unsupported_claim' in material else
                       'no_material_issue_found')
            assert report['verdict'] == verdict, (rid, report['verdict'], verdict)
            assert sha256(Path(source['anonymousReport']).read_bytes()).hexdigest() == source['anonymousSha256']
            if source['kind'] == 'candidate':
                assert sha256(Path(source['report']).read_bytes()).hexdigest() == source['reportSha256']
            reports.append({**report, 'kind': source['kind'], 'variant': source.get('variant'),
                            'expectedControl': source.get('expected'), 'review': path.name,
                            'originalReport': source.get('report'),
                            'hasMinorFinding': any(i['severity'] == 'minor' for i in issues)})
    assert seen == set(manifest) and len(reports) == 130
    sources = json.loads((ROOT / 'upstream-sources.json').read_text())
    for source in sources:
        assert sha256((ROOT / 'upstream' / source['tag'] / source['path']).read_bytes()).hexdigest() == source['sha256']
    candidates = [r for r in reports if r['kind'] == 'candidate']
    assert len(candidates) == 100
    assert Counter(r['gem'] for r in candidates) == {r['gem']: 10 for r in candidates}
    per_gem = defaultdict(Counter)
    for report in candidates:
        per_gem[report['gem']][report['verdict']] += 1
    controls = [{'id': r['id'], 'expected': r['expectedControl'], 'actual': r['verdict'],
                 'findings': r['finding_keys']} for r in reports if r['kind'] == 'control']
    anchors = [{'id': r['id'], 'priorId': manifest[r['id']]['priorId'],
                'priorVerdict': manifest[r['id']]['priorVerdict'], 'verdict': r['verdict']}
               for r in reports if r['kind'] == 'anchor']
    records = [manifest[r['id']] for r in candidates]
    summary = {
        'variants': {'sonnet-medium': {
            'reports': len(candidates), 'verdicts': Counter(r['verdict'] for r in candidates),
            'perGem': dict(per_gem), 'noRecordedFindings': sum(not r['finding_keys'] for r in candidates),
            'completedSessionListPriceUsd': sum(r['costUsd'] for r in records),
            'medianWorkerTools': median(r['toolCalls'] for r in records),
            'medianWorkerSeconds': median(r['usage']['duration_ms'] / 1000 for r in records),
        }},
        'controls': controls,
        'anchors': {'agreement': sum(r['priorVerdict'] == r['verdict'] for r in anchors),
                    'total': len(anchors), 'results': anchors},
        'validation': {'uniqueReports': len(reports), 'literalQuotationsChecked': quotations,
                       'originalReportsUnchanged': len(candidates), 'upstreamHashesVerified': len(sources),
                       'verdictPrecedenceAndBidirectionalReferences': 'passed'},
    }
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (ROOT / 'results.json').write_text(json.dumps({'summary': summary, 'reports': reports,
                                                 'findings': findings}, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
