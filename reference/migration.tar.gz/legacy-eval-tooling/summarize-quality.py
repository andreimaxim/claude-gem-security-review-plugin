"""Validate blind reviews, then reveal model identities and aggregate findings."""

from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
from statistics import median


ROOT = Path('.amp/in/artifacts/gem-upgrade-eval/quality-check-20261010')


def main():
    manifest = {r['id']: r for r in json.loads((ROOT / 'private-manifest.json').read_text())}
    reviews = []
    findings = []
    seen = set()
    literal_quotes = 0
    for path in sorted(ROOT.glob('review-*.json')):
        data = json.loads(path.read_text())
        indexed = {f['key']: f for f in data['findings']}
        report_index = {r['id']: r for r in data['reports']}
        assert len(indexed) == len(data['findings'])
        assert len(report_index) == len(data['reports'])
        for finding in data['findings']:
            for evidence in finding['report_evidence']:
                rid = evidence['id']
                assert finding['key'] in report_index[rid]['finding_keys']
                quote = evidence['quote']
                if quote:
                    assert quote in Path(manifest[rid]['anonymousReport']).read_text()
                    literal_quotes += 1
            findings.append({'review': path.name, **finding})
        for report in data['reports']:
            rid = report['id']
            assert rid not in seen
            seen.add(rid)
            source = manifest[rid]
            assert report['gem'] == source['gem']
            issues = [indexed[k] for k in report['finding_keys']]
            for issue in issues:
                assert rid in {e['id'] for e in issue['report_evidence']}
            material = {i['category'] for i in issues if i['severity'] == 'material'}
            expected = ('needs_correction' if 'false_claim' in material else
                        'insufficient' if 'material_omission' in material else
                        'needs_verification' if 'unsupported_claim' in material else
                        'no_material_issue_found')
            assert report['verdict'] == expected, (rid, report['verdict'], expected)
            if source['kind'] == 'candidate':
                assert sha256(Path(source['report']).read_bytes()).hexdigest() == source['reportSha256']
            reviews.append({**report, 'kind': source['kind'],
                            'variant': source.get('variant'), 'expectedControl': source.get('expected'),
                            'review': path.name, 'originalReport': source.get('report'),
                            'hasMinorFinding': any(i['severity'] == 'minor' for i in issues)})
    assert seen == set(manifest) and len(reviews) == 210
    for source in json.loads((ROOT / 'upstream-sources.json').read_text()):
        path = ROOT / 'upstream' / source['tag'] / source['path']
        assert sha256(path.read_bytes()).hexdigest() == source['sha256']

    variants = {}
    for variant in ('sonnet-high', 'haiku-high'):
        group = [r for r in reviews if r['variant'] == variant]
        assert len(group) == 100
        sources = [manifest[r['id']] for r in group]
        per_gem = defaultdict(Counter)
        for report in group:
            per_gem[report['gem']][report['verdict']] += 1
        variants[variant] = {
            'reports': len(group), 'verdicts': Counter(r['verdict'] for r in group),
            'perGem': dict(per_gem),
            'noRecordedFindings': sum(not r['finding_keys'] for r in group),
            'minorOnly': sum(r['verdict'] == 'no_material_issue_found' and bool(r['finding_keys']) for r in group),
            'coverage': {field: Counter(r['coverage'][field] for r in group)
                         for field in ('coupling', 'manifest', 'application', 'delta')},
            'completedSessionListPriceUsd': sum(r['costUsd'] for r in sources),
            'medianWorkerTools': median(r['toolCalls'] for r in sources),
            'medianWorkerSeconds': median(r['usage']['duration_ms'] / 1000 for r in sources),
        }
    controls = [r for r in reviews if r['kind'] == 'control']
    for control in controls:
        expected = ('no_material_issue_found' if control['expectedControl'] == 'correct'
                    else 'needs_correction')
        assert control['verdict'] == expected
    summary = {
        'scope': 'Completed reports only; ten Rails gems, 8.0.5 to 8.1.4, ten repetitions per model.',
        'variants': variants,
        'controls': {'correctAccepted': sum(r['expectedControl'] == 'correct' for r in controls),
                     'incorrectRejected': sum(r['expectedControl'] == 'incorrect' for r in controls)},
        'validation': {'uniqueReports': len(reviews), 'literalQuotationsChecked': literal_quotes,
                       'originalReportsUnchanged': 200, 'upstreamHashesVerified': 68,
                       'verdictPrecedenceAndBidirectionalReferences': 'passed'},
    }
    (ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    (ROOT / 'results.json').write_text(json.dumps({'summary': summary, 'reports': reviews,
                                                 'findings': findings}, indent=2) + '\n')
    lines = ['# Per-report quality findings', '',
             'These are evidence-review verdicts, not runtime compatibility or accuracy guarantees.', '',
             '| Model | Gem | Report | Verdict | Finding details |',
             '| --- | --- | --- | --- | --- |']
    for report in sorted((r for r in reviews if r['kind'] == 'candidate'),
                         key=lambda r: (r['variant'], r['gem'], r['id'])):
        relative = Path(report['originalReport']).resolve().relative_to(ROOT.parent.resolve())
        link = '../' + str(relative)
        keys = ', '.join(report['finding_keys']) or 'None recorded'
        lines.append(f"| {report['variant']} | {report['gem']} | [{report['id']}]({link}) | "
                     f"{report['verdict']} | [{keys}]({report['review']}) |")
    (ROOT / 'REPORTS.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
